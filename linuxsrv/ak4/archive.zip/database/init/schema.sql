CREATE TABLE IF NOT EXISTS messages (
    id         SERIAL PRIMARY KEY,
    author     TEXT        NOT NULL,
    body       TEXT        NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
